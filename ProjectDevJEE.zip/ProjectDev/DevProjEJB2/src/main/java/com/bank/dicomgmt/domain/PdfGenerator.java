/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bank.dicomgmt.domain;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

/**
 *
 * @author cesi
 */
public class PdfGenerator {
    
    public static void PdfCreate(String name, String contenu){
        
        Document doc = new Document(PageSize.A4);

        try{
            PdfWriter.getInstance(doc, new FileOutputStream(name));
            doc.open();
            Paragraph paragHeader = new Paragraph(new Phrase("TAUX DE CONFIANCE POUR LE DOCUMENT: "+ name + "\n", FontFactory.getFont(FontFactory.HELVETICA, 18)));
            
            Paragraph paragBody = new Paragraph(new Phrase(contenu, FontFactory.getFont(FontFactory.HELVETICA, 12)));
            
            doc.add(paragHeader);
            doc.add(paragBody);
        }
        catch(DocumentException de) {
            System.err.println(de.getMessage());
        }
        catch(IOException ioe) {
            System.err.println(ioe.getMessage());
        }
        
        doc.close();
        System.out.println("Document PDF: "+name+" is generated!");
    }
}
