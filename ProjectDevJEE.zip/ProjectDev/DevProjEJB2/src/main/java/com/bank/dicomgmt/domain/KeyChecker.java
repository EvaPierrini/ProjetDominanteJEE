/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bank.dicomgmt.domain;

/**
 *
 * @author cesi
 */
import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class KeyChecker implements Serializable{
    
    @XmlAttribute
    private String value;
    
    @XmlElement
    private KeyStatus status;
    
    @XmlAttribute
    private Double countFIND;

    @XmlAttribute
    private Double countALL;
    
    public void createKey(KeyChecker key, String value, KeyStatus status){
        key.setStatus(status.WRONG);
        key.setValue(value);
        key.setCountFIND(0.0);
        key.setCountALL(0.0);
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public KeyStatus getStatus() {
        return status;
    }

    public void setStatus(KeyStatus status) {
        this.status = status;
    }

    public Double getCountFIND() {
        return countFIND;
    }

    public void setCountFIND(Double countFIND) {
        this.countFIND = countFIND;
    }

    public Double getCountALL() {
        return countALL;
    }

    public void setCountALL(Double countALL) {
        this.countALL = countALL;
    }
    
    @Override
    public String toString() {
       double rsltVal = (countFIND/countALL)*100;
       return "Accuracy of sent text is: "+ String.valueOf(rsltVal) +"%.";
    }    
}

