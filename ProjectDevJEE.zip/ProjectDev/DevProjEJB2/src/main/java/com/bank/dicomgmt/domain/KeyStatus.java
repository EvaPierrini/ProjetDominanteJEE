/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bank.dicomgmt.domain;

import javax.xml.bind.annotation.XmlEnum;

/**
 *
 * @author cesi
 */
@XmlEnum
public enum KeyStatus {
    VALIDATED, WRONG
}
