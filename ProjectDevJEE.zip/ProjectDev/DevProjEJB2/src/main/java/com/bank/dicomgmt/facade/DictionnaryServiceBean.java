/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bank.dicomgmt.facade;

import com.bank.dicomgmt.domain.KeyChecker;
import com.bank.dicomgmt.domain.KeyStatus;
import com.bank.dicomgmt.domain.PdfGenerator;
import com.bank.dicomgmt.integration.Dictionnary;
import javax.ejb.Stateless;
import javax.jws.WebService;
import com.bank.dicomgmt.integration.DictionnaryFacade;
import java.io.StringWriter;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.inject.Inject;
import javax.jms.JMSContext;
import javax.jms.Queue;
import javax.jms.TextMessage;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.ws.BindingType;

/**
 *
 * @author cesi
 */
@Stateless
@WebService(
endpointInterface = "com.bank.dicomgmt.facade.DictionnaryServiceEndpointInterface",
portName = "DicoPort", 
serviceName = "DicoService"
 )
//@BindingType("http://java.sun.com/xml/ns/jaxws/2003/05/soap/bindings/HTTP/") 
public class DictionnaryServiceBean implements DictionnaryServiceEndpointInterface{

    @Inject
    private DictionnaryFacade dicoFacade;
    private Dictionnary dico;
    
    @Inject //paquetage javax.inject
    private JMSContext context; //paquetage javax.jms
    
    @Resource(lookup = "jms/keyCheckerQueue") //paquetage javax.annotation
    private Queue keyCheckerQueue; //paquetage javax.jms

    
    public Dictionnary getDico() {
        return dico;
    }

    public void setDico(Dictionnary dico) {
        this.dico = dico;
    }
        
    @Override
    public String findRightKey(String key, byte[] fileContent, String docName) {
                        
        double countFIND = 0;
        double countALL = 0;

        boolean secretFound = false;
        String pdfRow = "";
        final Charset fromCharset = Charset.forName("windows-1252");
        final Charset toCharset = Charset.forName("UTF-8");
        KeyChecker enteredKey = new KeyChecker();
        
        List<String> cypherTab;
        cypherTab = new ArrayList<>();
        
        String cypherText = new String(fileContent);
        
        try{
            if(key.length()== 4 ){   
                //System.out.println("La valeur de la clé est : "+ key);

                enteredKey.createKey(enteredKey, key, KeyStatus.WRONG);
                
                String[] tempTab = cypherText.split(" ");
                for (String tempTab1 : tempTab) {
                    String fixed = new String(tempTab1.getBytes(fromCharset), toCharset);
                    cypherTab.add(fixed.toLowerCase().replaceAll("\\.", "").replaceAll("\\!", "").replaceAll("\\?", "").replaceAll("'", ""));
                }
                //Il est tout à fait possible de devenir docteur dans ce monde.
                
                //System.out.println(dicoFacade.find(dico));
                //dico = dicoFacade.find(BigDecimal.ONE);
                //System.out.println(dico);
                for(int i=0; i<cypherTab.size(); i++){
                    int lenResult = dicoFacade.getWordLib(cypherTab.get(i)).size();
                    
                    //TODO commencer a ajouter les count dès que un aura matché (si i == 10 toujours rien, on abort)
                    try{
                    if(lenResult!=0){
                        countFIND++;
                        countALL++;
                        pdfRow += "\nWord "+ i +" ('"+ cypherTab.get(i)+"'): "+ dicoFacade.getWordLib(cypherTab.get(i));
                        if("linformation".equals(cypherTab.get(i)) && "secrete".equals(cypherTab.get(i+1))){
                            secretFound = true;
                        }
                        System.out.println(cypherTab.get(i)+": "+dicoFacade.getWordLib(cypherTab.get(i)));
                    }
                    else{
                        countALL++;
                        pdfRow += " \nWord ('"+cypherTab.get(i)+"') not found in Oracle database 'Dictionnary'";
                        //System.out.println("Data (word) '"+cypherTab.get(i)+"' not found in Oracle database 'Dictionnary'");
                    }
                    }
                    catch(Exception ex){
                    }
                    if(cypherTab.size()>10){
                        if((countFIND/countALL)*100 < 50 && (i==cypherTab.size()-1 || i==20)){
                            enteredKey.setCountFIND(countFIND);
                            enteredKey.setCountALL(countALL);
                            break;
                        }
                        else if((countFIND/countALL)*100 >= 50 && (i==cypherTab.size()-1 || i==20)){
                            enteredKey.setCountFIND(countFIND);
                            enteredKey.setCountALL(countALL);
                            pdfRow += "\n\n\tLe taux de confiance trouvé est de: "+ (countFIND/countALL)*100 + "%, la clé '"+key+"' est VALIDE!";
                            enteredKey.setStatus(KeyStatus.VALIDATED);
                            break;
                        }
                    }
                    else{
                        if((countFIND/countALL)*100 < 50 && i==cypherTab.size()-1){
                            enteredKey.setCountFIND(countFIND);
                            enteredKey.setCountALL(countALL);
                            break;
                        }
                        else if((countFIND/countALL)*100 >= 50 && i==cypherTab.size()-1){
                            enteredKey.setCountFIND(countFIND);
                            enteredKey.setCountALL(countALL);
                            pdfRow += "\n\n\tLe taux de confiance trouvé est de: "+ (countFIND/countALL)*100 + "%, la clé '"+key+"' est VALIDE!";
                            enteredKey.setStatus(KeyStatus.VALIDATED);
                            break;
                        }
                    }
                    
                }
                
                if(enteredKey.getStatus()== KeyStatus.VALIDATED){
                    if("AAAS".equals(key)){
                        System.out.println(cypherText);
                    }
                    System.out.println(enteredKey);
                    System.out.println(key+ " is a valid Key, the text is approximatively written in French!");
                    if(secretFound){
                        PdfGenerator.PdfCreate("pdgGenerated", pdfRow);
                        sendValidKey(enteredKey);
                        pdfRow=null; cypherTab=null; enteredKey = null;
                        Runtime.getRuntime().gc(); 
                        System.out.println("The secret code has been found");
                        return "key: "+key+", nomDoc: "+docName+", found: True, Text: "+ cypherText;
                    }
                    else
                        return "ERROR: key valid but not right file";
                }
                else
                    System.out.println("The '"+key+"' key is not valid for this text!");
                    //System.out.println(countFIND);
                    //System.out.println(countALL);
                    //double rsltVal = (countFIND/countALL)*100;
                    //System.out.println("Accuracy of sent text is: "+ String.valueOf(rsltVal) +"%.");
                    pdfRow=null; cypherTab=null; enteredKey = null;
                    Runtime.getRuntime().gc(); 

                    return "ERROR: The '"+key+"' key is not valid for this text!";
            } else {
                pdfRow=null; cypherTab=null; enteredKey = null;
                Runtime.getRuntime().gc(); 
                return "ERROR: There is an error in your inputs!";
            }
        }
        catch (Exception ex){
            System.out.println("Une erreur à été détecté");
              
            // Prints what exception has been thrown 
            pdfRow=null; cypherTab=null; enteredKey = null;
            Runtime.getRuntime().gc(); 
            //System.out.println(ex); 
            return "ERROR:" + ex;
        }
        
    }
   
    
    private void sendValidKey(KeyChecker paramKey){
        //utilisation de l'API JAX-B de gestion de flux pour marshaller (transformer) l'objet //Payment en chaine XML
        JAXBContext jaxbContext;
        try {
            //obtention d'une instance JAXBContext associée au type Payment annoté avec JAX-B
            jaxbContext = JAXBContext.newInstance(KeyChecker.class);
            //création d'un Marshaller pour transfomer l'objet Java en flux XML
            Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
            
            StringWriter writer = new StringWriter();
            
            //transformation de l'objet en flux XML stocké dans un Writer
            jaxbMarshaller.marshal(paramKey, writer);
            String xmlMessage = writer.toString();
            
            //affichage du XML dans la console de sortie
            System.out.println(xmlMessage);
	    //encapsulation du paiement au format XML dans un objet javax.jms.TextMessage
            TextMessage msg = context.createTextMessage(xmlMessage);
            
            //envoi du message dans la queue paymentQueue
            context.createProducer().send(keyCheckerQueue, msg);


        } catch (JAXBException ex) {
            Logger.getLogger(DictionnaryServiceBean.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}

