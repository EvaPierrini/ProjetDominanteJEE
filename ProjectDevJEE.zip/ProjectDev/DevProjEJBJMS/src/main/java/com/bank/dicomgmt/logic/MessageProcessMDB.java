/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bank.dicomgmt.logic;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import java.io.IOException;
import java.util.concurrent.TimeoutException;

/**
 *
 * @author cesi
 */
@MessageDriven(activationConfig = {
    @ActivationConfigProperty(propertyName = "destinationLookup", propertyValue = "jms/keyCheckerQueue")
    ,
        @ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue")
})
public class MessageProcessMDB implements MessageListener {
    
    public MessageProcessMDB() {
    }
    
    @Override
    public void onMessage(Message message) {
        try {
            //on extrait le paiment du corps du message. - getBody est une méthode JMS 2.0
            String uncrytptedMessage = message.getBody(String.class);
            for(int i = 0; i<=5;i++){
                System.out.println("[traitement long d'integration dans le processus déchiffrage de la clé...] "+(i+1)+"/6");
            }

            
            //service.helloWorld();
            //System.out.println(service.helloWorld());
            
            System.out.println("l'objet clé de chiffrement "+uncrytptedMessage+" va être retiré de la queue");
        } catch (JMSException ex) {
            Logger.getLogger(MessageProcessMDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    
}
